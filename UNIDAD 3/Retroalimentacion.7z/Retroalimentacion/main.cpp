#include <iostream>
#include <conio.h>

using namespace std;
struct Nodo{
 int dato;
 Nodo *ptrSiguiente, *ptrAtras;
};
struct Nodo1{
    int valor;
    Nodo1 *ptrSig;
};
void menu();
void insertar_nodo();
void mostrarLista_P_U();
void mostrarLista_U_P();
void buscar_elemento();
void eliminar_elemento();
void insertar_Listasimple();
void mostrarLista_simple();
Nodo *Primero, *Ultimo;
Nodo1 *lista;
Nodo1 *siguiente;
int main()
{
    Primero = NULL;
    Ultimo=NULL;
    lista=NULL;
    siguiente= NULL;
    menu();
    return 0;
}
void menu(){
int opcion;
do{
    cout<<"******Menu*****"<< endl;
    cout <<"1. Crear lista doblemente enlazada"<<endl;
    cout <<"2. Mostrar elementos de la lista de primero al ultimo"<<endl;
    cout <<"3. Mostrar elementos de la lista del ultimo al primero"<< endl;
    cout <<"4. Buscar elemento en la lista"<<endl;
    cout <<"5. Eliminar elemento de la lista"<<endl;
    cout <<"6. Insertar lista simple"<<endl;
    cout <<"7. Mostrar lista simple"<<endl;
    cout <<"8. Salir"<< endl;
    cout << "Que Opcion deseas"<<endl;
    cin>>opcion;
    switch (opcion){
        case 1:
            insertar_nodo();
            break;
        case 2:
            mostrarLista_P_U();
            break;
        case 3:
            mostrarLista_U_P();
            break;
        case 4:
            buscar_elemento();
            break;
        case 5:
            eliminar_elemento();
            break;
        case 6:
            insertar_Listasimple();
            break;
        case 7:
            mostrarLista_simple();
            break;

    }
    system("cls");
}while (opcion !=8);
}
void insertar_nodo(){

    while (lista != NULL){
        Nodo *nuevo = new Nodo();

    nuevo->dato = lista->valor;
    if (Primero == NULL){
        Primero= nuevo;
        Primero->ptrAtras = NULL;
        Primero->ptrSiguiente=NULL;
        Ultimo = Primero;
    }
    else{
        Ultimo->ptrSiguiente= nuevo;
        nuevo->ptrAtras= Ultimo;
        nuevo->ptrSiguiente= NULL;
        Ultimo = nuevo;
    }
    lista= lista->ptrSig;

    }
     cout<< "Lista completa"<<endl;
    system("pause");


}
void mostrarLista_P_U(){
 Nodo *actual = new Nodo();
 actual = Primero;
 if (Primero != NULL){
    while(actual != NULL){
        cout << "<- "<< actual->dato<<" ->";
        actual= actual->ptrSiguiente;
    }
    cout<< endl;

 }
 else{
    cout<< "La lista esta vacia"<<endl;
 }
 system("pause");
}
void mostrarLista_U_P(){
Nodo *actual = new Nodo();
 actual = Ultimo;
 if (Ultimo != NULL){
    while(actual != NULL){
        cout << "<- "<< actual->dato<<" ->";
        actual= actual->ptrAtras;
    }
    cout<< endl;

 }
 else{
    cout<< "La lista esta vacia"<<endl;
 }
 system("pause");
}
void buscar_elemento(){
Nodo *actual = new Nodo();
 actual = Primero;
 int ebuscado;
 bool bandera=false;
 cout<<"Que dato desea buscar??"<<endl;
 cin>>ebuscado;
 if (Primero != NULL){
    while(actual != NULL){
        if(actual->dato== ebuscado){
           bandera = true;
           break;
        }
        actual= actual->ptrSiguiente;
    }
    if (bandera==true){
        cout<<"Valor encontrado"<<endl;
    }
    else{
        cout <<"El valor no se encuentra en la lista"<<endl;
    }
}
 else{
    cout<< "La lista esta vacia"<<endl;
 }
 system("pause");
}
void eliminar_elemento(){
Nodo *actual = new Nodo();
Nodo *anterior = new Nodo();
 actual = Primero;
 anterior =NULL;
 int ebuscado;
 bool bandera=false;
 cout<<"Que dato desea Eliminar??"<<endl;
 cin>>ebuscado;
 if (Primero != NULL){
    while((actual != NULL)&& (bandera!=true)){
        if(actual->dato== ebuscado){
          if(actual==Primero){
            Primero= Primero->ptrSiguiente;
            Primero->ptrAtras= NULL;
          }else if(actual == Ultimo){
           anterior->ptrSiguiente=NULL;
           Ultimo=anterior;
          }
          else{
            anterior->ptrSiguiente=actual->ptrSiguiente;
            actual = actual->ptrAtras;
          }
          cout<< "El elemento ha sido eliminado";
          bandera =true;
        }
        anterior = actual;
        actual= actual->ptrSiguiente;
    }
    if (bandera != true)
        cout <<"El valor no se encuentra en la lista"<<endl;
    }
    else{
    cout<< "La lista esta vacia"<<endl;
 }
 system("pause");
}
void insertar_Listasimple(){
Nodo1 *nuevo1 = new Nodo1();
    cout<< "Ingrese un elemento a la lista"<<endl;
    cin>> nuevo1->valor;
    if (lista == NULL){
        lista= nuevo1;
        lista->ptrSig=NULL;
        siguiente=  lista;

    }
    else{
        siguiente->ptrSig= nuevo1;
        nuevo1->ptrSig= NULL;
        siguiente = nuevo1;
    }
    cout<< "El elemento ha sido agregado"<<endl;
    system("pause");

}
void mostrarLista_simple(){
 Nodo1 *actual = new Nodo1();
 actual = lista;
 if (lista != NULL){
    while(actual != NULL){
        cout << "<- "<< actual->valor<<" ->";
        actual= actual->ptrSig;
    }
    cout<< endl;

 }
 else{
    cout<< "La lista esta vacia"<<endl;
 }
 system("pause");
}

